import { v2 as cloudinary } from 'cloudinary';

cloudinary.config({
    cloud_name: "dlhgkeru5",
    api_key: "186782924673368",
    api_secret: "_mNsQypMTOShbhiqlgt4lHqaDyM"
});

export default cloudinary;
